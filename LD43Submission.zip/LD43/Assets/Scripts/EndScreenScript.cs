﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class EndScreenScript : MonoBehaviour {

    public Animator endAnim;
    public TextMeshProUGUI timeTxt, scoreTxt;
    public int timeMulti;
    public GameObject endPanel;

    GameController gc;
    public AudioManager am;

    private void Start()
    {
        gc = GameObject.Find("Scripts").GetComponent<GameController>();
    }

    public void GameOver(int time, int points) {
        endAnim.SetBool("Scaling", true);
        TextUpdate(time, points);
        StartCoroutine(TimeToPoints(time, points));
    }

    public IEnumerator TimeToPoints(int time, int points) {

        yield return new WaitForSeconds(2f);

        if (time > 0) {
            for (int i = time; i >= 0; i--)
            {
                TextUpdate(i, points);
                if (i <= 0) {
                    break;
                }

                points += timeMulti;
                
                yield return new WaitForSeconds(.1f);
            }

            

        }

        FillStars(points);


    }

    public void TextUpdate(int time, int points)
    {
        timeTxt.SetText("Remaining Time: " + time);
        scoreTxt.SetText("Score: " + points);
    }

    public void FillStars(int points) {

        if (points < gc.star1Points)
        {
            Debug.Log("none");
            endAnim.SetBool("NoStars", true);

        }

        if (points >= gc.star1Points) {

            endAnim.SetBool("Star1", true);

        }

        if (points >= gc.star1Points && points < gc.star2Points) {

            endAnim.SetBool("1not2", true);
        }

        if (points >= gc.star2Points)
        {

            endAnim.SetBool("Star2", true);

        }

        if (points >= gc.star3Points)
        {

            endAnim.SetBool("Star3", true);

        }
    }

    public void StopScaling() {
        endPanel.GetComponent<RectTransform>().localScale = new Vector3(1, 1, 1);
        //endAnim.SetBool("Scaling", false);
    }

    public void PlayStar() {

        am.PlayStar();
    }
}
