﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioManager : MonoBehaviour {

    public AudioSource hit, killBad, killGood, star;

    public void PlayHit() {
        hit.Play();

    }

    public void PlayKillBad() {
        killBad.Play();

    }

    public void PlayKillGood() {

        killGood.Play();
    }

    public void PlayStar() {
        star.Play();

    }
}
