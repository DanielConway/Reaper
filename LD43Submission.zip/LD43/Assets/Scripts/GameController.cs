﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;

public class GameController : MonoBehaviour {

    public int score;
    public float time = 100;
    public bool gameIsActive;
    public int innocentAlive;
    public int criminalsAlive;

    public int star1Points, star2Points, star3Points;

    public TextMeshProUGUI scoreTxt, timeTxt, crimTxt, inTxt, endTxt;
    public GameObject endPanel;

    GameController gc;

	// Use this for initialization
	void Start () {
        gc = GameObject.Find("Scripts").GetComponent<GameController>();
        gameIsActive = true;
        Killed();
	}
	
	// Update is called once per frame
	void Update () {

        if (time >= 0 && gameIsActive == true)
        {
            TimeUpdate(- Time.deltaTime);
            timeTxt.SetText("TIME: " + (int)time);
        }
        


    }

    public void ToLevel1() {

        SceneManager.LoadScene(2);
    }

    public void DoneLevel1()
    {
        if (score >= star2Points)
        {
            SceneManager.LoadScene(3);

        }

        else {
            SceneManager.LoadScene(2);
        }
        
    }

    public void DoneLevel2()
    {
        if (score >= star2Points)
        {
            SceneManager.LoadScene(4);

        }

        else
        {
            SceneManager.LoadScene(3);
        }

    }

    public void DoneLevel3()
    {
        if (score >= star2Points)
        {
            SceneManager.LoadScene(5);

        }

        else
        {
            SceneManager.LoadScene(4);
        }

    }

    public void ScoreUpdate(int points) {

        score += points;
        scoreTxt.SetText("SCORE: " + score.ToString("0000"));
    }

    public void TimeUpdate(float points)
    {

        time += points;
        timeTxt.SetText("TIME: " + (int) time);

        if (time <= 0 && gameIsActive == true) {
            gameIsActive = false;
            CallGameOver();
        }
    }

    public void Killed() {
        crimTxt.SetText("Criminals Alive: " + criminalsAlive);
        inTxt.SetText("Citizens Alive: " + innocentAlive);

        if (criminalsAlive <= 0) {

            CallGameOver();
        }

    }

    private void CallGameOver() {
        endPanel.SetActive(true);
        gameIsActive = false;
        

        if ((int)(score + time) < star2Points)
        {
            endTxt.SetText("Retry");
        }

        if ((int)(score + time) >= star2Points)
        {
            endTxt.SetText("Next Level");
        }

        Debug.Log("S:" + (int)(score + time));
        Debug.Log("R:" + star2Points);

        endPanel.GetComponent<EndScreenScript>().GameOver((int)time, score);
    }
}
