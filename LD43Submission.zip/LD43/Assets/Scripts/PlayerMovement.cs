﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour {

    public GameObject player;
    public GameObject playerGfx;
    private Rigidbody rb;
    public int speed;
    private Camera camera;
    private Vector3 mousePos;
    [HideInInspector]
    public GameObject activeInteraction;
    public GameObject interactionPanel;
    public GameObject point;
    private GameObject activePoint;

    private GameController gc;
    private Vector3 lookDir;
    private Animator playerAnim;

    public AudioManager am;


    // Use this for initialization
    void Start () {

        rb = player.GetComponent<Rigidbody>();
        mousePos = player.transform.position;
        camera = Camera.FindObjectOfType<Camera>();
        gc = GameObject.Find("Scripts").GetComponent<GameController>();
        playerAnim = player.GetComponent<Animator>();
		
	}
	
	// Update is called once per frame
	void Update () {

        if (Input.GetMouseButtonDown(0) && gc.gameIsActive == true)
        {

            RaycastHit hit;
            Ray ray = camera.ScreenPointToRay(Input.mousePosition);
            
            if (Physics.Raycast(ray, out hit))
            {
                if (hit.collider.gameObject.tag == "Ground")
                {
                    if (activePoint != null) {
                        Destroy(activePoint);
                    }
                    mousePos = hit.point;
                    //playerGfx.transform.LookAt(new Vector3(mousePos.x,player.transform.position.y,mousePos.z));
                    lookDir = new Vector3(mousePos.x - playerGfx.transform.position.x, playerGfx.transform.position.y - 1, mousePos.z - playerGfx.transform.position.z);
                    activePoint = Instantiate(point, hit.point, Quaternion.identity, null);

                }
            }
        }

        if (Input.GetKeyDown(KeyCode.Space) && playerAnim.GetBool("Attacking") == false) {

            if (activeInteraction != null) {

                int health = activeInteraction.GetComponent<InteractionObject>().health;
                if (activeInteraction.gameObject.tag == "Enemy" || activeInteraction.gameObject.tag == "Innocent") {
                    
                    playerAnim.SetBool("Attacking", true);
                    am.PlayHit();
                    activeInteraction.GetComponent<InteractionObject>().health--;
                    if (health > 1) {
                        activeInteraction.GetComponent<InteractionObject>().RunAway();
                    }

                    if (health <= 1)
                    {

                        if (activeInteraction.gameObject.tag == "Enemy") {
                            am.PlayKillBad();
                            gc.ScoreUpdate(10);
                            gc.criminalsAlive--;
                        }

                        if (activeInteraction.gameObject.tag == "Innocent")
                        {
                            am.PlayKillGood();
                            gc.ScoreUpdate(-5);
                            gc.innocentAlive--;
                            gc.TimeUpdate(5);
                        }

                        gc.Killed();
                        
                        Destroy(activeInteraction);
                        activeInteraction = null;
                        interactionPanel.SetActive(false);
                    }
                }
                

            }
            
        }

    }

    private void FixedUpdate()
    {
        if (gc.gameIsActive == true) {
            rb.velocity = new Vector3(0, 0, 0);
            if (player.transform.position.x != mousePos.x || player.transform.position.z != mousePos.z)
            {


                player.transform.position = Vector3.MoveTowards(player.transform.position, new Vector3(
                mousePos.x,
                player.transform.position.y,
                mousePos.z
                ), speed * Time.deltaTime);

            }

            if (lookDir != new Vector3(0, 0, 0))
            {
                Quaternion rot = Quaternion.LookRotation(lookDir);
                playerGfx.transform.rotation = Quaternion.Slerp(playerGfx.transform.rotation, rot, speed * Time.deltaTime);
            }
        }
        
        

    }

    public void StopAttack() {

        playerAnim.SetBool("Attacking", false);
    }
}
