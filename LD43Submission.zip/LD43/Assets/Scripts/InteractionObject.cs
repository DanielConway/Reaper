﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InteractionObject : MonoBehaviour {

    public GameObject interactionPanel;
    public GameObject player;
    PlayerMovement pm;
    public int health;
    public bool bad;
    public bool running;
    public int speed;
    private Vector3 lookDir;
    public GameObject enemyGfx;

    private int xLoc, zLoc;

	// Use this for initialization
	void Start () {
        pm = player.GetComponent<PlayerMovement>();
		
	}

    private void OnTriggerEnter(Collider col)
    {
        if (col.gameObject.tag == "Player") {

            interactionPanel.SetActive(true);

            pm.activeInteraction = this.transform.gameObject;
        }
    }

    private void OnTriggerExit(Collider col)
    {
        if (col.gameObject.tag == "Player")
        {

            interactionPanel.SetActive(false);

            pm.activeInteraction = null;

        }
    }

    public void RunAway() {

        running = true;
        xLoc = Random.Range(-50, 50);
        zLoc = Random.Range(-50, 50);
        lookDir = new Vector3(xLoc, this.transform.position.y, zLoc) - transform.position;

    }

    private void FixedUpdate()
    {

        if (running == true) {
            this.transform.position = Vector3.MoveTowards(this.transform.position, lookDir, speed * Time.deltaTime);
        }

        if (lookDir != new Vector3(0,0,0))
        {
            Quaternion rot = Quaternion.LookRotation(lookDir);
            enemyGfx.transform.rotation = Quaternion.Slerp(enemyGfx.transform.rotation, rot, speed * Time.deltaTime);
        }

    }
}
