﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Cinemachine;

public class CameraScript : MonoBehaviour {

    private Camera camera;
    public float speed;

    private float yOffset, zOffset;

    public int yOffSpeed, zOffSpeed;


	// Use this for initialization
	void Start () {
        camera = Camera.FindObjectOfType<Camera>();

        yOffset = 25;
        zOffset = -5;

        camera.transform.rotation = Quaternion.Euler(75, 0, 0);
    }
	
	// Update is called once per frame
	void Update () {

        //curRot += Input.GetAxisRaw("Mouse ScrollWheel") * rotMulti;

        //camera.transform.rotation = Quaternion.Lerp(camera.transform.rotation, Quaternion.Euler(curRot, 0, 0), Time.deltaTime * rotSpeed);
        
        yOffset = Mathf.Clamp(yOffset, 10, 50)  - Input.GetAxisRaw("Mouse ScrollWheel") * yOffSpeed;
        zOffset = Mathf.Clamp(zOffset, -10f, -2.5f) + Input.GetAxisRaw("Mouse ScrollWheel") * zOffSpeed;

        camera.GetComponent<CinemachineVirtualCamera>().GetCinemachineComponent<CinemachineTransposer>().m_FollowOffset = Vector3.Lerp(
            camera.GetComponent<CinemachineVirtualCamera>().GetCinemachineComponent<CinemachineTransposer>().m_FollowOffset,
            new Vector3(0, yOffset, zOffset),
            Time.deltaTime * speed);

    }
}
